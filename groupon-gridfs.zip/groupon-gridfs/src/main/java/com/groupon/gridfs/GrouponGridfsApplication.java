package com.groupon.gridfs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrouponGridfsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrouponGridfsApplication.class, args);
	}

}
